# ShellCanvas app SDK

Build desktop apps that install while ShellCanvas is running. The SDK supplies typed, window-owned system services over the desktop's isolated app channel. It needs no React, Tauri or Node dependency in the app bundle. The included CLI uses Node and esbuild at development time.

Version **0.1.0 is published on npm and remains provisional**. Install it with `npm install --save-dev @techartdev/shellcanvas-app-sdk`; no ShellCanvas checkout is required. The 0.x API is still subject to change, so pin the version and test against the desktop you target.

## Create and build an app

With this package installed as a development dependency:

```sh
npx shellcanvas-app init ./my-app --id org.example.notes --title "Notes"
cd my-app
npm install
npm run build
```

The output is `dist/app.shellcanvas.json`. Open ShellCanvas's **App Manager → Add apps → Choose package…**, select it, review the permissions and open the app. No desktop rebuild/restart is needed. For an update, change the manifest version and rebuild. Existing windows keep their code and grants until closed; a new window uses the installed version.

The generator requires a new directory and never overwrites an existing project. The generated project depends on the published SDK; pass `--sdk <tarball>` only to consume a locally packed build instead. Call the CLI through a local install (`npx shellcanvas-app`, or an npm script): `npx -p @techartdev/shellcanvas-app-sdk shellcanvas-app …` exits without running. `shellcanvas-app build [directory] --version 0.2.0` overrides the artifact's version without editing the manifest. `shellcanvas-app validate <package>` invokes the same package parser used by the desktop.

## Public API

To distribute through GitHub, build first and run
`shellcanvas-app repository . --description "What your app does"`.
Commit both the generated root `shellcanvas.repo.json` and its referenced package.
Preserve package bytes with a final `dist/app.shellcanvas.json -text` rule in
`.gitattributes`. Users choose **App Manager → Add apps → From GitHub** and review the exact
downloaded package. Installation downloads files directly; it runs no npm scripts
and requires no registry or GitHub API token. See the repository schema exported
at `@techartdev/shellcanvas-app-sdk/schemas/app-repository.schema.json`.

For a user-configured HTTP service, declare `system.network` and use
`network.configure({slot, suggestedEndpoint})` to open ShellCanvas's credential
dialog. The returned connection contains endpoint/revision metadata, never the key.
`network.postJSON({slot, revision, body}, signal?)` returns a response with
`status`, `contentType`, `read()` and `close()`; always close it in `finally`.
Only the configured endpoint receives the request; redirects are rejected.
The host owns authentication and cancellation. Network permission does not grant
remote host files or console access. Apps can open locally with unavailable host
actions disabled.

```ts
import { connectToShellCanvas, RpcError } from "@techartdev/shellcanvas-app-sdk";

const desktop = await connectToShellCanvas();
try {
  const answer = await desktop.system.dialogs.messageBox({
    title: "Continue?",
    message: "Choose what to do with your note.",
    buttons: [
      { id: "continue", label: "Continue" },
      { id: "cancel", label: "Cancel" },
    ],
    defaultId: "continue",
    cancelId: "cancel",
  });
} catch (error) {
  if (error instanceof RpcError) console.error(error.code, error.message);
}
```

| Service                | API                                                                                 | Required grants                                                                             |
| ---------------------- | ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| Shared message box     | `system.dialogs.messageBox(options, {signal}?)`                                     | `system.dialogs`                                                                            |
| Open/Save selection    | `system.dialogs.openFile(options?, control?)`, `saveFile(options?, control?)`       | `system.dialogs`, `files.read`                                                              |
| Save text workflow     | `system.files.saveTextAs({text, name?, directory?, allowReplace?}, control?)`       | `system.dialogs`, `files.read`, `files.create`; replacement additionally needs `files.edit` |
| Own window state       | `window.setDocumentState({dirty, busy, title?})`, `window.getState(signal?)`        | Intrinsic to this app window                                                                |
| Window actions         | `window.focus`, `minimize`, `maximize`, `restore`, `requestClose` (optional signal) | Intrinsic; active workspace only                                                            |
| Local data/preferences | `storage` and `settings`: `get`, `put`, `remove`, `list`                            | `system.storage`                                                                            |
| Environment/discovery  | `environment.get(signal?)`, `services.list(signal?)`                                | Intrinsic; individual methods still enforce their grants                                    |
| State events           | `events.subscribe(listener, onError?)` returns an unsubscribe function              | Intrinsic; event contents are filtered by the host                                          |
| Text clipboard         | `clipboard.readText(signal?)`, `writeText(text, signal?)`                           | `system.clipboard.read` or `system.clipboard.write`                                         |
| Custom device services | `services.call(method, params?, signal?)`                                           | `services.<service-id>` for the selected adapter service                                    |

Service calls are asynchronous. `events.subscribe` synchronously returns an unsubscribe function, and `dispose()` synchronously closes the instance channel; page teardown does this automatically. `connectToShellCanvas(timeoutMs?)` must run inside a desktop-owned app frame. Named types, `Json`, `RpcCode` and `RpcError` are exported from the package root. Manifest parsers/types are available from `@techartdev/shellcanvas-app-sdk/package`.

Window actions affect only the calling window in the active workspace. `getState()`
returns visibility, focus, layout mode and `canMaximize`; maximize is unavailable
in compact layouts. Restore clears tiling/maximization and restores visibility.
`requestClose()` uses normal busy/draft protection. Its reply acknowledges a
request, not completed closure or user consent to discard. Save before requesting
close: the app and channel may disappear before a reply or continuation executes.
Cancellation cannot undo an already accepted window action.

Image clipboard methods are `clipboard.readImage(signal?)` and
`clipboard.writeImage({width, height, rgba}, signal?)`. `rgba` is a `Uint8Array`
with four bytes per pixel in top-to-bottom row order. They require separate
`system.clipboard.image.read` / `system.clipboard.image.write` grants; text grants
never authorize image access. Use service discovery for availability. The broker
streams 32 KiB chunks and publishes only a complete image. Reads and writes capture
their pixels, so subsequent caller/clipboard changes do not alter an in-progress
snapshot. Dimensions must match the exact byte count. Images need memory for their
pixels; there is no application-specific total-image cap. Cancellation cannot undo
native publication; inspect uncertain outcomes before retrying. For file publication,
use the file clipboard methods below. Custom formats and mobile image support
remain outside this contract.

`clipboard.pasteFiles({ binding, path }, signal?)` prepares native clipboard files
and folders for upload, same-workspace remote copy, or a Cut move. It requires
`system.clipboard.files.read` and the corresponding `files.upload`, `files.copy` or `files.move`
grant. The returned array contains owned transfer handles; preparation
does not start them. Call `run`, inspect the result, and `close` each handle using
the transfer API. Empty/non-file clipboard contents return an empty array.
Windows Explorer file-list input and this process's own remote clipboard selections
are supported; other platforms and foreign virtual-file inputs are unavailable.
A locally cut selection uploads a copy and keeps its
source. Native file paths are not returned in ticket fields. Large selections
share one job; contents stream natively and folders use disk-backed discovery.
Pending native preparation remains busy until it returns, even after cancellation.
A cut produces a `direction: "move"` job bound to its original workspace/provider.
Only one paste may reserve it. Cancel before dispatch to release that reservation;
after dispatch, await the authoritative outcome and never automatically retry an
uncertain move. Multiple-item cuts and cross-process moves remain follow-ups.
`clipboard.cutFile({ binding, path, revision }, signal?)` publishes one current
file or folder as a move reference. Declare `system.clipboard.files.write` and
`files.move`. It does not move the item until Paste runs. Installed apps and
bundled Files can paste it in the original workspace and ShellCanvas process.
This method does not expose file contents to Explorer: Move permission alone
does not grant Download. Use `copyFiles` for external content export. Cut shares
Copy's mandatory publication busy guard; cancellation after dispatch may be too
late, so never automatically retry an uncertain publication.
`clipboard.copyFiles(entries, signal?)` exports remote `{ binding, path, revision }`
entries to the Windows clipboard. Declare `system.clipboard.files.write` and
`files.download`. References must use one accepted binding and current revisions.
The SDK snapshots and chunks root metadata; native code discovers folders and
streams contents only when Explorer requests them. Keep the desktop and source
connection open until external Paste finishes. Copy completion means publication,
not a completed destination transfer. Cancellation cannot retract a publication
already dispatched to the OS; do not retry uncertain results automatically.
Pending native preparation remains host-enforced busy work, independently of an
app's reported document state. Remote Copy selections are shared between installed
apps and bundled Files in the original workspace. Another workspace or replaced
file-service connection is refused. The SDK captures and checks the clipboard
version before preparation; it never falls back to another transfer permission.
Multiple-item cuts, cross-process selection sharing and custom formats remain follow-ups.

`call(method, params?, signal?)` uses the explicit broker method map and permission checks. It is not a native-command escape hatch. Use `services.call` for custom adapter methods. Discover methods first; `granted` and `available` are separate. Custom entries include the advertised service version and an opaque `source` identity. Declare `services.acme.sensor` to request access to a selected `acme.sensor` service; all its advertised methods share that grant. The app never supplies a native session or source ID. Custom JSON result validation belongs to the app and adapter contract.

## Ownership, cancellation and errors

`hostSettings.read({binding}, signal?)` requires `host.settings.read` and returns provider-defined `RemoteHostSetting` fields. `hostSettings.apply(field, value, signal?)` requires `host.settings.write`, submits the captured binding/ID/revision, and returns confirmed state. This is separate from local `settings` storage. Render field labels, choices, read-only reasons and nullable revisions; check both method permission/availability and field writability. Apps own proposal/review UI, while the provider checks values, revisions and account access. Source changes refuse old settings and late results. A canceled request can leave a native write running; the desktop holds its busy guard until that write settles. One read and one apply may be outstanding per window, including canceled native work. Keep proposals and refresh after uncertain failures; writes are never retried automatically.

`transfers.upload(destination, {folder?: boolean}?, signal?)`, `download(entry, signal?)`, `downloadMany(entries, signal?)` and `copy(entry, destination, signal?)` prepare window-owned jobs. Grants are `files.upload`, `files.download` and `files.copy` respectively. Locations include the accepted binding; entries include a directory revision. Upload/download uses native local choosers. Folder upload also needs device folder capability. Dismissal returns an empty array or `null` for single download.

A transfer handle provides `run(signal?)`, `status()`, `watch(signal?)`, `cancel()` and `close()`. Preparation does not start bytes; `run` starts once and reports the actual completed/canceled/failed result. Canceling a running job is a request, so a late successful publication still reports completion. A failed cancellation remains retryable and keeps the window busy. `close` waits for cleanup/outcome. Progress snapshots coalesce; stopping observation does not cancel the transfer. File bytes and native IDs remain outside the app, and local download paths are omitted. Source changes cannot retarget a handle. The desktop automatically guards unfinished transfers even if the app reports `busy: false`. Release finished handles; a window may retain 32 jobs and one pending chooser. Native multi-selection uploads and downloads return one catalog-backed batch job, with no fixed root-count or tree depth/count cap. Returned job arrays do not correspond one-to-one with selected files. Batch cancellation preserves completed items.

`console.open({binding, cols?, rows?}, signal?)` requires `system.console` and returns a window-owned byte channel with `read`, `write`, `resize`, `close`, and `resizable`. `read()` returns up to 64 KiB or `null` at EOF; `write(Uint8Array | string)` sends bytes or UTF-8 text in chunks. Read and write concurrently. Await writes; only one read and one write may be pending per console. Output is backpressured until consumed, with no total stream-size limit. A window may own 16 consoles, including pending opens and cleanup. Fixed-size consoles retain I/O but reject resize.

Close consoles in `finally`. The optional opening signal controls the console lifetime; aborting an individual operation also closes it because bytes may already have crossed the boundary. Never retry uncertain input automatically. Connection changes retire old handles; acceptance requires opening a new console. Native handles are not exposed. Closing one console preserves others on the same connection.

Enable each remote action using both `granted` and `available` from service discovery, and refresh after `system.services` or `system.environment` events. A device can support browsing without text documents: `files.read` alone does not establish `system.files.readText` availability. The optional environment `operations` map narrows capability support; missing lists retain the legacy contract. Read-only text access does not require edit/create permission. Keep drafts when a service disappears, and discard stale discovery replies after a newer refresh starts.

File actions use directory-entry revisions: `files.makeDirectory({binding, parent, name}, signal?)`, `renameEntry({binding, path, revision}, name, signal?)`, `moveEntry(entry, {binding, path}, signal?)` and `removeEntry(entry, signal?)`. Moving requires `files.move`; the other three require `files.manage`. Source and destination bindings must match. Creation/rename/move return an opaque `RemoteFileLocation`; refresh the listing for a new revision afterward. These methods refuse replacement and do not implement recursive deletion or cross-host moves. They do not display confirmation dialogs; use shared dialogs in the app's workflow. A directory-entry revision is not interchangeable with a text-document revision.

`files.list({binding, path?}, signal?)` is an async iterable of directory pages. Omit `path` for the provider default. Each page includes opaque parent/home/roots, entries and its binding. Use `for await`; breaking the loop or aborting releases the listing, and connection changes retire old iterators. Pages are bounded, with no total entry-count limit. The current backend materializes a directory before delivery; the public iterator can support incremental providers. A window may retain up to 16 simultaneous listings; close unused iterators before opening more.

For remote text, capture `environment.get().binding` before opening a file picker, then pass `{binding, path}` to `files.readText`. Keep the returned `RemoteTextDocument` alongside the draft and pass it unchanged to `files.saveText(document, newText)`. The snapshot includes the exact binding and revision; old snapshots are rejected after connection replacement. Never substitute a fresh binding/revision to force a save. `files.createText({binding, parent, name, text}, signal?)` creates only and requires `files.create`; reading needs `files.read`, saving needs `files.edit`. Use `system.files.saveTextAs` for reviewed replacement. These methods accept an optional AbortSignal. Text service size limits apply; binary and folder transfers are separate APIs still under development.

Each client belongs to one window, package/grant generation and explicitly accepted workspace binding. It cannot choose another window or native session ID. Reconnect can require explicit user approval before old app windows use a new connection. Preserve drafts while waiting; observe `system.environment` events for connection/visibility changes. Event batches with `reset: true` are current snapshots rather than a complete historical replay.

`environment.get().workspaceId` is an optional opaque **configured target identity**
for associating persistent documents or conversations with a workspace. It survives
reconnecting and renaming the same target. SSH targets distinguish endpoint, port
and account; composite targets distinguish source configuration and routing.
Changing a composite configuration conservatively changes identity. Compare values
only; do not parse them, route operations with them, or treat them as proof of the
remote machine's identity. Host-key and binding checks remain separate. Null or
absent means unknown (including older desktops); a matching display name is never
evidence of a matching workspace. Local desktop identity is distinct from remote
targets. A desktop installation or profile migration may require renewed consent.

Use `AbortSignal` for cancelable calls. Closing the instance rejects pending calls and releases resources. Cancellation cannot undo a dispatched write. Do not automatically retry failed writes, saves or clipboard publication. Report dirty/busy state so the desktop can review close and quit requests. Mark a draft clean only if the saved snapshot still matches the editor contents.

Storage is local to the app identity and survives package updates/removal. `put(key, value, null)` creates only; replacement requires the revision returned by `get`/`put`. A revision conflict must be reviewed or reloaded, not blindly retried. `list({after, limit})` is paginated live state. Storage is not a credential vault. File locations are opaque provider values: do not split, join or translate them. Open/Save selections do not themselves write data or authorize overwriting.

| Error code    | Meaning and response                                                                  |
| ------------- | ------------------------------------------------------------------------------------- |
| `invalid`     | Fix the request shape or unsupported option.                                          |
| `denied`      | Required permission is absent; explain which feature needs it.                        |
| `unavailable` | The service or current connection does not support the action.                        |
| `closed`      | The owning channel/window/binding has retired.                                        |
| `aborted`     | The call was canceled; dispatched effects may still have occurred.                    |
| `busy`        | Resource or concurrency capacity is occupied; avoid unbounded queues.                 |
| `failed`      | The operation failed; preserve work and inspect the result before retrying mutations. |

User dismissal normally returns `null` from dialogs and save workflows. Host-originated failures use `RpcError`; handshake failures can be ordinary errors. Type declarations describe the supported API, not additional authority.

## Package and compatibility

Edit `main.ts`, `style.css` and `shellcanvas.json`. The bundled schemas describe the source manifest and executable package. Source manifests may contain `$schema` for editor completion; packaging removes it. The desktop enforces additional resource bounds: 16 Mi UTF-16 units for a package and 100 UTF-16 units for a title. These are app metadata/control limits, not remote file-tree limits.

App listings show an icon, the title and an optional short description:

```json
{
  "title": "Notes",
  "description": "Quick notes for your remote hosts.",
  "icon": "icon.svg"
}
```

- `description` is one line of at most 160 UTF-16 code units, without control characters (C0 or C1) or Unicode line and paragraph separators.
- `icon` names a PNG, JPEG, WebP or SVG file (lowercase extension) inside the app directory. `shellcanvas-app build` embeds it in the package as a base64 data URI and refuses files over 256 KiB or whose contents do not match the extension. Square artwork of at least 128 pixels with its own background works best, because listings round the corners. The desktop never fetches icon URLs, and SVG icons render as images without running scripts.
- Both fields are optional. Apps without an icon get the generic app icon. `shellcanvas-app repository` uses the package description unless `--description` is given.

Packages with `description` or `icon` need desktop 0.1.2 or newer: the 0.1.0 and 0.1.1 parsers reject unknown package fields. Packages without them install on every release.

All JavaScript must be bundled. External assets, runtime imports, networking, native Tauri IPC and Node APIs are unavailable in UI app frames. Use provider-owned desktop services for remote access. Native adapters are separate, explicitly trusted executable packages.

The client uses app channel v1 and format-1 packages. Discover optional methods instead of assuming every host has them. Version 0.x APIs remain subject to change; pin the SDK and test against the target desktop. This package does not claim a stable future ABI, a marketplace, non-Windows native isolation or complete virtual-OS coverage.
